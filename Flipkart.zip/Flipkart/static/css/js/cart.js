<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Select all delete links
        const deleteLinks = document.querySelectorAll('.cart_quantity_delete');

        deleteLinks.forEach(link => {
            link.addEventListener('click', function(event) {
                event.preventDefault(); // Prevent the default link behavior

                const itemId = this.getAttribute('data-item-id');

                // Send AJAX request to delete item
                fetch(`/delete_item/${itemId}/`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRFToken': getCookie('csrftoken') // Include CSRF token if using Django
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove item row from table
                        this.closest('tr').remove();
                    } else {
                        alert('Failed to delete item');
                    }
                })
                .catch(error => console.error('Error:', error));
            });
        });

        // Helper function to get CSRF token (for Django)
        function getCookie(name) {
            let cookieValue = null;
            if (document.cookie && document.cookie !== '') {
                const cookies = document.cookie.split(';');
                for (let i = 0; i < cookies.length; i++) {
                    const cookie = cookies[i].trim();
                    if (cookie.substring(0, name.length + 1) === (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }
    });
</script>
