from django.db import models 
from .db import db_conn
from django.contrib.auth.models import User

# Create your models here.
flipusers=db_conn['flipusers']
flipreview=db_conn['flipreview']
flipreplay=db_conn['flipreplay']
flipcontact=db_conn['flipcontact']
flipbill=db_conn['flipbill']
 
 
 

 


  


 






