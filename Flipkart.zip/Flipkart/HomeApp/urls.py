from django.urls import path
from . import views

urlpatterns=[
    path("",views.login1,name="login1"),
    path("register",views.register,name="register"),
    path("registeruser",views.registeruser,name="registeruser"),    
    path("index",views.index,name="index"),
    path("loginuser",views.loginuser,name="loginuser"),
    path("login1",views.login1,name="login1"),
    path("cart",views.cart,name="cart"),
    path("checkout",views.checkout,name="checkout"),
    path("product_details",views.product_details,name="product_details"),
    path("ureview",views.ureview,name="ureview"),
    path("shop",views.shop,name="shop"),
    path("blog",views.blog,name="blog"),
    path("blog_single",views.blog_single,name="blog_single"),
    path("replay",views.replay,name="replay"),
    path("contact-us",views.contact_us,name="contact_us"),
    path("404",views.error,name="error"),
    path("contact",views.contact,name="contact"),
    path("logout",views.logout,name="logout"),
    path("bill",views.bill,name="bill"),
    path("track",views.track,name="track"),
    path("confpopup",views.confpopup,name="confpopup"),
    path("main",views.main,name="main"),
    path("track_order",views.track_order,name="track_order"),
    path("account",views.account,name="account"),
]