from django.shortcuts import render
from django.http import HttpResponse
from .models import flipusers,flipreview,flipreplay,flipcontact,flipbill

# Create your views here.
def login1(request):
    return render(request,"login1.html")
def register(request):
    return render(request,"register.html")
def loginuser(request):
    return render(request,"index.html")
def registeruser(request): 
    name=request.POST['name']
    email=request.POST['email']   
    password=request.POST['password']
    mobile=request.POST['mobile']
    address=request.POST['address']
    country=request.POST['country']
    post=request.POST['post']
    count=flipusers.count_documents({"mobile":mobile})
    if count==0:
        data={
            "name":name,            
            "email":email,
            "password":password,
            "mobile":mobile,
            "address":address,
            "country":country,
            "post":post            
        }     
        flipusers.insert_one(data)
        all_data=flipusers.find()
        return render(request,"popup.html",{'data':all_data})
    else:
        all_data=flipusers.find()
        print("<-- DATA IS ALREADY INSERTED -->")  
        return render(request,"account.html",{'data':all_data})  
    return render(request,"login1.html")    

def index(request):
    return render(request,"index.html")
def cart(request):
    return render(request,"cart.html")
def checkout(request):
    return render(request,"checkout.html")
def product_details(request):
    return render(request,"product_details.html")
def ureview(request):
    name=request.POST['name']
    email=request.POST['email']
    review=request.POST['review']
    data1={
        "name":name,
        "email":email,
        "review":review
    }
    flipreview.insert_one(data1)
    return render(request,"product_details.html")
def shop(request):
    return render(request,"shop.html")
def blog(request):
    return render(request,"blog.html")
def blog_single(request):
    return render(request,"blog_single.html")
def replay(request):
    uname=request.POST['uname']
    email=request.Post['email']
    city=request.POST['city']
    message=request.POST['message']
    data2={
        "uname":uname,
        "email":email,
        "city":city,
        "message":message,
    }
    flipreplay.insert_one(data2)
    return render(request,"blog_single.html")
def contact_us(request):
    return render(request,"contact-us.html")
def error(request):
    return render(request,"404.html")
def contact(request):
    name=request.POST['name']
    email=request.POST['email']
    subject=request.POST['subject']
    message=request.POST['message']
    data3={
        "name":name,
        "email":email,
        "subject":subject,
        "message":message,
    }
    flipcontact.insert_one(data3)
    return render(request,"contact-us.html")
def logout(request):
    return render(request,"login1.html")
def bill(request):
    name=request.POST['name']
    email=request.POST['email']
    address1=request.POST['address1']
    address2=request.POST['address2']
    pincode=request.POST['pincode']
    phone=request.POST['phone']
    data4={
        "name":name,
        "email":email,
        "address1":address1,
        "address2":address2,
        "pincode":pincode,
        "phone":phone,
    }
    flipbill.insert_one(data4)
    return render(request,"confpopup.html")
def track(request):
    return render(request,"track.html")
def confpopup(request):
    return render(request,"confpopup.html")
def main(request):
    return render(request,"main.html")
def track_order(request):
    status = request.POST.get('status', None)
    return render(request, 'track_order.html', {'status': status})
def account(request): 
        all_data=flipusers.find() 
        return render(request,"account.html",{'data':all_data})  
    


 